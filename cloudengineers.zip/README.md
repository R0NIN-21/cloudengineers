# Relic Map

A responsive, dependency-free student field guide to NASA spacecraft and mission hardware left across the solar system. It starts with approachable questions, explains key space-science vocabulary, and links to NASA references for further research.

## Run locally

Serve this directory with any static web server, for example:

```sh
python3 -m http.server 8000
```

Then open `http://localhost:8000`.

The page includes question-led exploration paths, a quick glossary, location filters, an interactive landing-site map, artifact hotspots and sliders, a flip-to-reveal science card, a replayable three-question Signal Hunt, a mission-patch passport, and a probe power challenge. It is designed to be useful without prior space-science knowledge. Coordinates are approximate landing-site references; use the linked NASA catalogs for mission data.