const missions = {
  curiosity: {
    name: "Curiosity", world: "MARS · GALE CRATER", date: "AUG 2012", status: "STILL ROVING",
    description: "A car-sized science lab rolling through an ancient lakebed. Its layers of rock tell the story of a wetter Mars.",
    finding: "Ancient Mars had the ingredients to support microbial life.", coords: "4.59° S, 137.44° E", index: "04.01", location: "mars"
  },
  opportunity: {
    name: "Opportunity", world: "MARS · MERIDIANI PLANUM", date: "JAN 2004", status: "SIGNAL SILENT",
    description: "A six-wheeled geologist that kept climbing, rolling, and finding clues long after its 90-sol mission was meant to end.",
    finding: "Hematite “blueberries” revealed that liquid water once shaped Martian rocks.", coords: "1.95° S, 354.47° E", index: "04.02", location: "mars"
  },
  spirit: {
    name: "Spirit", world: "MARS · GUSEV CRATER", date: "JAN 2004", status: "SIGNAL SILENT",
    description: "A twin rover that crossed a crater, climbed a hill, and found signs that hot water once altered Martian rock.",
    finding: "Silica-rich soil pointed to ancient hydrothermal activity on Mars.", coords: "14.57° S, 175.47° E", index: "04.03", location: "mars"
  },
  insight: {
    name: "InSight", world: "MARS · ELYSIUM PLANITIA", date: "NOV 2018", status: "SIGNAL SILENT",
    description: "A stationary lander that listened for marsquakes and measured the planet’s deep interior for four years.",
    finding: "Seismic waves gave scientists their first detailed look inside Mars.", coords: "4.50° N, 135.62° E", index: "04.04", location: "mars"
  },
  apollo: {
    name: "Apollo 11", world: "THE MOON · TRANQUILITY BASE", date: "JUL 1969", status: "STILL SCIENTIFIC",
    description: "The descent stage stayed on the Moon. Its laser retroreflector still helps measure the distance between Earth and the Moon.",
    finding: "Laser returns show the Moon is slowly drifting away from Earth.", coords: "0.67° N, 23.47° E", index: "01.01", location: "moon"
  },
  voyager: {
    name: "Voyager 1", world: "DEEP SPACE · INTERSTELLAR", date: "SEP 1977", status: "SIGNAL ACTIVE",
    description: "The most distant human-made object. It crossed into interstellar space and still sends a faint signal home.",
    finding: "Voyager revealed the outer planets and now samples interstellar space.", coords: "24+ BILLION KM FROM EARTH", index: "05.01", location: "deep"
  }
};

const hotspotNotes = {
  power: {
    number: "NODE 01", label: "POWER", title: "Sunlight,<br>stored as science.",
    description: "Wide solar arrays fed Opportunity’s batteries. Martian dust slowly covered the cells—until a planet-wide storm cut off the light for good.",
    fact: "A lucky gust sometimes swept the panels clean, giving the rover a fresh burst of power."
  },
  arm: {
    number: "NODE 02", label: "SCIENCE", title: "A geologist<br>on the move.",
    description: "The robotic arm placed instruments against rocks and brushed away dust. Tiny iron-rich spheres in the rock became clues to Mars’ watery past.",
    fact: "Those round hematite-rich deposits earned the nickname “blueberries.”"
  },
  signal: {
    number: "NODE 03", label: "SIGNAL", title: "A whisper<br>across space.",
    description: "A high-gain antenna aimed toward Earth, sending science data home as radio waves. Deep Space Network dishes caught the faint signal.",
    fact: "Voyager’s radio signal is extraordinarily faint by the time it reaches Earth."
  }
};

const timelineLabels = [
  { caption: "A QUIET, CLEAR SKY", stage: "SOL 1, 2004", dusty: false },
  { caption: "THE FIRST DUSTY SEASON", stage: "SOL 1,000", dusty: false },
  { caption: "A PLANET-WIDE STORM", stage: "SOL 5,000", dusty: true },
  { caption: "THE FINAL SIGNAL", stage: "SOL 5,111, 2018", dusty: true }
];

const discoveryFacts = {
  curiosity: "Curiosity found ancient lakebed chemistry with the key ingredients that could support microbial life.",
  opportunity: "Ancient Mars had water: tiny hematite spheres, nicknamed “blueberries,” left a clue in the rocks.",
  spirit: "Spirit found silica-rich soil—evidence that hot water once flowed through this part of Mars.",
  insight: "Mars has marsquakes: seismic waves revealed new details about the planet’s deep interior.",
  apollo: "The Moon is slowly drifting away from Earth, measured with laser pulses bounced off Apollo reflectors.",
  voyager: "Voyager 1 crossed the heliopause and is sampling the space between the stars."
};

let selectedSite = "curiosity";
let selectedWorld = "mars";
let selectedHotspot = "power";
let selectedDestination = "mars";
let selectedPower = "solar";
let quizRound = 0;
let quizScore = 0;
let quizAnswered = false;
let quizComplete = false;
let toastTimer;
let globeRotation = 0;
let dragStartX = 0;
let rotationAtDragStart = 0;
let isDraggingGlobe = false;
let didDragGlobe = false;
let suppressMapClick = false;

const byId = id => document.getElementById(id);
const mapGlobe = byId("map-globe");

const signalQuestions = [
  {
    question: "Which rover found tiny iron-rich spheres nicknamed “blueberries”?",
    hint: "This rover was designed for a 90-sol mission, but it explored Mars for more than 14 years.",
    answer: "opportunity",
    choices: [["spirit", "Spirit"], ["opportunity", "Opportunity"], ["curiosity", "Curiosity"]],
    explanation: "Opportunity found hematite-rich spheres. Hematite forms in some watery environments, so these “blueberries” became clues about Mars’ past."
  },
  {
    question: "Which mission left a laser reflector on the Moon that scientists still use?",
    hint: "Two astronauts landed at Tranquility Base in July 1969.",
    answer: "apollo",
    choices: [["luna", "Luna 9"], ["apollo", "Apollo 11"], ["survey", "Surveyor 3"]],
    explanation: "Apollo 11 astronauts placed a retroreflector on the Moon. Scientists bounce laser pulses off it to measure the Earth–Moon distance."
  },
  {
    question: "What keeps Voyager 1 powered so far from the Sun?",
    hint: "It turns heat from naturally decaying radioactive material into electricity.",
    answer: "rtg",
    choices: [["solar", "Large solar panels"], ["rtg", "A radioisotope power system"], ["battery", "A rechargeable battery only"]],
    explanation: "Voyager uses an RTG. It converts heat from plutonium-238 decay into electricity, so the spacecraft does not depend on sunlight."
  }
];

function selectSite(siteId) {
  const mission = missions[siteId];
  if (!mission) return;
  selectedSite = siteId;

  byId("console-id").textContent = mission.index;
  byId("console-world").textContent = mission.world;
  byId("console-title").textContent = mission.name;
  byId("console-description").textContent = mission.description;
  byId("console-date").textContent = mission.date;
  byId("console-status").textContent = mission.status;
  byId("console-coords").textContent = mission.coords;
  byId("map-coordinates").textContent = mission.coords;
  byId("console-finding").textContent = mission.finding;

  document.querySelectorAll(".map-beacon").forEach(beacon => {
    beacon.classList.toggle("is-selected", beacon.dataset.site === siteId);
  });
  document.querySelectorAll(".hero-beacon").forEach(beacon => {
    beacon.classList.toggle("is-selected", beacon.dataset.site === siteId);
  });
  unlockMissionPatch(siteId);

  const fleetCard = document.querySelector(`.fleet-card[data-site="${siteId}"]`);
  const fleetFilter = document.querySelector(".filter-chip.is-active")?.dataset.filter;
  if (fleetCard && fleetFilter && fleetFilter !== "all" && fleetCard.dataset.location !== fleetFilter) {
    document.querySelectorAll(".filter-chip").forEach(chip => chip.classList.toggle("is-active", chip.dataset.filter === "all"));
    document.querySelectorAll(".fleet-card").forEach(card => { card.hidden = false; });
    byId("fleet-count").textContent = "05";
  }
  showMissionArtifact(siteId);
}

function showMissionArtifact(siteId) {
  const mission = missions[siteId];
  if (!mission) return;
  const labels = {
    curiosity: ["CURIOSITY / MSL", "006", "AUG 2012", "687 sols", "13+ years", "MISSION PLAN", "MISSION LIFE", "Still exploring"],
    opportunity: ["OPPORTUNITY / MER-B", "002", "JAN 2004", "90 sols", "5,111 sols", "PLANNED", "ACTUAL", "“My battery is low and it’s getting dark.”"],
    spirit: ["SPIRIT / MER-A", "003", "JAN 2004", "90 sols", "2,208 sols", "PLANNED", "ACTUAL", "The rover fell silent after getting stuck in soft soil."],
    insight: ["INSIGHT / SEIS", "004", "NOV 2018", "2 years", "4 years", "PLANNED", "ACTUAL", "The lander sent its final message in December 2022."],
    apollo: ["APOLLO 11 / LRRR", "001", "JUL 1969", "DEPLOYED", "RANGING TODAY", "LEFT ON MOON", "IN USE", "Laser pulses still return from the lunar reflector."],
    voyager: ["VOYAGER 1 / PWS", "005", "SEP 1977", "4 years", "49+ years", "PLANNED", "STILL ACTIVE", "Voyager 1 continues to send data from interstellar space."]
  };
  const values = labels[siteId];
  if (values) {
    byId("artifact-label").textContent = values[0];
    byId("artifact-mission-index").textContent = values[1];
    byId("discovery-file-id").textContent = `${values[1]} / 006`;
    byId("life-planned-label").textContent = values[5];
    byId("life-planned").textContent = values[3];
    byId("life-actual-label").textContent = values[6];
    byId("life-actual").textContent = values[4];
    byId("discovery-note-label").textContent = siteId === "opportunity" ? "LAST WORDS" : "FIELD NOTE";
    byId("discovery-quote").textContent = values[7];
    byId("discovery-note").textContent = siteId === "opportunity"
      ? "A poetic paraphrase often used to describe its final transmission—not the literal radio message."
      : "A short mission note—not a direct quotation from spacecraft telemetry.";
    byId("timeline-start").textContent = values[2];
    byId("timeline-end").textContent = siteId === "opportunity" ? "JUN 2018" : mission.status === "SIGNAL ACTIVE" || siteId === "curiosity" || siteId === "apollo" ? "NOW" : "MISSION END";
  }
  byId("discovery-fact").textContent = discoveryFacts[siteId];
  byId("discovery-card").classList.remove("is-flipped");
}

document.querySelectorAll(".filter-chip").forEach(chip => {
  chip.addEventListener("click", () => {
    document.querySelectorAll(".filter-chip").forEach(item => item.classList.toggle("is-active", item === chip));
    let visible = 0;
    document.querySelectorAll(".fleet-card").forEach(card => {
      const show = chip.dataset.filter === "all" || card.dataset.location === chip.dataset.filter;
      card.hidden = !show;
      if (show) visible++;
    });
    byId("fleet-count").textContent = String(visible).padStart(2, "0");
  });
});

document.querySelectorAll("[data-site]").forEach(button => {
  button.addEventListener("click", () => {
    const siteId = button.dataset.site;
    if (missions[siteId]) {
      if (missions[siteId].location !== selectedWorld && button.classList.contains("hero-beacon")) {
        setWorld(missions[siteId].location);
      }
      selectSite(siteId);
      if (button.classList.contains("text-link")) byId("map").scrollIntoView({ behavior: "smooth" });
      if (button.classList.contains("hero-beacon")) byId("map").scrollIntoView({ behavior: "smooth" });
    }
  });
});

function setWorld(world) {
  selectedWorld = world;
  mapGlobe.classList.toggle("world-moon", world === "moon");
  mapGlobe.classList.toggle("world-deep", world === "deep");
  setGlobeRotation(0);
  byId("map-top-label").textContent = world === "mars" ? "MARS / GLOBAL VIEW" : world === "moon" ? "THE MOON / NEAR SIDE" : "DEEP SPACE / OUTBOUND";
  byId("beacon-readout").textContent = world === "mars" ? "04 BEACONS IN RANGE" : "01 BEACON IN RANGE";
  document.querySelectorAll(".map-tab").forEach(tab => {
    const active = tab.dataset.world === world;
    tab.classList.toggle("is-active", active);
    tab.setAttribute("aria-selected", String(active));
  });
  const defaultSites = { mars: "curiosity", moon: "apollo", deep: "voyager" };
  selectSite(defaultSites[world]);
}

function setGlobeRotation(rotation) {
  globeRotation = Math.max(-55, Math.min(55, rotation));
  mapGlobe.style.setProperty("--globe-rotation", `${globeRotation}deg`);
  const worldName = selectedWorld === "mars" ? "Mars" : selectedWorld === "moon" ? "the Moon" : "deep space";
  mapGlobe.setAttribute("aria-label", `Interactive ${worldName} map, rotated ${Math.round(globeRotation)} degrees. Drag or use the left and right arrow keys to rotate.`);
}

function finishGlobeDrag() {
  if (!isDraggingGlobe) return;
  isDraggingGlobe = false;
  mapGlobe.classList.remove("is-dragging");
  if (didDragGlobe) {
    suppressMapClick = true;
    setTimeout(() => { suppressMapClick = false; }, 0);
  }
}

mapGlobe.addEventListener("pointerdown", event => {
  if (event.button !== 0 || event.target.closest(".map-beacon")) return;
  isDraggingGlobe = true;
  didDragGlobe = false;
  dragStartX = event.clientX;
  rotationAtDragStart = globeRotation;
  mapGlobe.classList.add("is-dragging");
  mapGlobe.setPointerCapture(event.pointerId);
});
mapGlobe.addEventListener("pointermove", event => {
  if (!isDraggingGlobe) return;
  const delta = event.clientX - dragStartX;
  if (Math.abs(delta) > 4) didDragGlobe = true;
  if (didDragGlobe) setGlobeRotation(rotationAtDragStart + delta * 0.65);
});
mapGlobe.addEventListener("pointerup", finishGlobeDrag);
mapGlobe.addEventListener("pointercancel", finishGlobeDrag);
mapGlobe.addEventListener("keydown", event => {
  if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
    event.preventDefault();
    setGlobeRotation(globeRotation + (event.key === "ArrowRight" ? 15 : -15));
  } else if (event.key === "Home") {
    event.preventDefault();
    setGlobeRotation(0);
  }
});
byId("map-reset").addEventListener("click", () => setGlobeRotation(0));
byId("surprise-mission").addEventListener("click", () => {
  const options = Object.keys(missions).filter(siteId => siteId !== selectedSite);
  const missionId = options[Math.floor(Math.random() * options.length)];
  const mission = missions[missionId];
  setWorld(mission.location);
  selectSite(missionId);
});

document.querySelectorAll(".map-tab").forEach(tab => tab.addEventListener("click", () => setWorld(tab.dataset.world)));
document.querySelectorAll(".map-beacon").forEach(beacon => {
  beacon.addEventListener("click", event => {
    if (suppressMapClick) {
      event.preventDefault();
      event.stopPropagation();
      suppressMapClick = false;
      return;
    }
    const mission = missions[beacon.dataset.site];
    if (mission && mission.location !== selectedWorld) {
      setWorld(mission.location);
    } else {
      selectSite(beacon.dataset.site);
    }
  });
});
byId("open-artifact").addEventListener("click", () => byId("artifact").scrollIntoView({ behavior: "smooth" }));

document.querySelectorAll(".hotspot").forEach(button => {
  button.addEventListener("click", () => {
    const note = hotspotNotes[button.dataset.hotspot];
    selectedHotspot = button.dataset.hotspot;
    byId("hotspot-number").innerHTML = `${note.number} <span>·</span> ${note.label}`;
    byId("hotspot-title").innerHTML = note.title;
    byId("hotspot-description").textContent = note.description;
    byId("hotspot-fact").textContent = note.fact;
    document.querySelectorAll(".hotspot").forEach(item => item.classList.toggle("is-active", item === button));
  });
});

byId("xray-slider").addEventListener("input", event => {
  const amount = Number(event.target.value);
  byId("xray-value").textContent = `${amount}%`;
  byId("rover-model").style.setProperty("--dissect-panel", `${amount * 0.36}px`);
  byId("rover-model").style.setProperty("--dissect-arm", `${-amount * 0.19}px`);
  byId("rover-model").style.filter = `drop-shadow(0 11px 10px #0009) brightness(${1 - amount / 450})`;
});

byId("time-slider").addEventListener("input", event => {
  const progress = Number(event.target.value);
  const stageIndex = Math.min(3, Math.floor(progress / 25));
  const stage = timelineLabels[stageIndex];
  byId("timeline-caption").textContent = stage.caption;
  byId("artifact-stage-label").textContent = stage.stage;
  byId("rover-model").classList.toggle("dusty", stage.dusty);
});

const discoveryCard = byId("discovery-card");
function flipDiscoveryCard() { discoveryCard.classList.toggle("is-flipped"); }
discoveryCard.addEventListener("click", flipDiscoveryCard);
discoveryCard.addEventListener("keydown", event => {
  if (event.key === "Enter" || event.key === " ") {
    event.preventDefault();
    flipDiscoveryCard();
  }
});

document.querySelectorAll("[data-destination]").forEach(button => {
  button.addEventListener("click", () => {
    selectedDestination = button.dataset.destination;
    document.querySelectorAll("[data-destination]").forEach(item => item.classList.toggle("is-selected", item === button));
    updateMissionResult();
  });
});
document.querySelectorAll("[data-power]").forEach(button => {
  button.addEventListener("click", () => {
    selectedPower = button.dataset.power;
    document.querySelectorAll("[data-power]").forEach(item => item.classList.toggle("is-selected", item === button));
    updateMissionResult();
  });
});

document.querySelectorAll("[data-study-site]").forEach(button => {
  button.addEventListener("click", () => {
    const mission = missions[button.dataset.studySite];
    if (!mission) return;
    setWorld(mission.location);
    selectSite(button.dataset.studySite);
    byId("map").scrollIntoView({ behavior: "smooth" });
  });
});

document.querySelectorAll("[data-study-destination]").forEach(button => {
  button.addEventListener("click", () => {
    selectedDestination = button.dataset.studyDestination;
    selectedPower = button.dataset.studyPower;
    document.querySelectorAll("[data-destination]").forEach(item => {
      item.classList.toggle("is-selected", item.dataset.destination === selectedDestination);
    });
    document.querySelectorAll("[data-power]").forEach(item => {
      item.classList.toggle("is-selected", item.dataset.power === selectedPower);
    });
    updateMissionResult();
    byId("mission-lab").scrollIntoView({ behavior: "smooth" });
  });
});

function updateMissionResult() {
  const isMismatched = selectedDestination === "deep" && selectedPower === "solar";
  const results = {
    "mars-solar": ["A bright idea.", "Solar panels work well at Mars—when the dust stays away. Pack a backup plan for storm season."],
    "mars-nuclear": ["Ready for the long haul.", "An RTG keeps making power through dust storms and the Martian night. Extra warmth for the ride."],
    "moon-solar": ["Mind the long night.", "A lunar night lasts about two Earth weeks. Your panels need a battery big enough to bridge the dark."],
    "moon-nuclear": ["Built for the shadows.", "An RTG keeps your instruments warm and working—even inside a permanently shadowed crater."],
    "deep-solar": ["Not enough sunlight.", "Far from the Sun, sunlight fades fast. Your panels can’t keep up—the probe is going cold. Try nuclear power."],
    "deep-nuclear": ["Hello, deep space.", "An RTG supplies steady power far from the Sun. That’s how Voyager keeps sending its whisper home."]
  };
  const [title, description] = results[`${selectedDestination}-${selectedPower}`];
  const result = document.querySelector(".lab-result");
  result.classList.toggle("is-warning", isMismatched);
  byId("result-status").textContent = isMismatched ? "POWER MISMATCH" : "LOOKS GOOD";
  byId("result-title").textContent = title;
  byId("result-description").textContent = description;
  byId("result-mark").textContent = isMismatched ? "!" : "✓";
}

function showGameToast(message) {
  byId("game-toast-message").textContent = message;
  byId("game-toast").classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => byId("game-toast").classList.remove("is-visible"), 3200);
}

function unlockPassportBadge(badgeId, message) {
  const badge = document.querySelector(`[data-passport-badge="${badgeId}"]`);
  if (!badge || badge.classList.contains("is-earned")) return;
  badge.classList.add("is-earned");
  badge.querySelector("i").textContent = "EARNED";

  const missionPatches = document.querySelectorAll(".passport-patch.is-earned").length;
  byId("passport-count").textContent = `${missionPatches}/5`;
  byId("passport-message").textContent = missionPatches === 5
    ? "All five mission patches collected. Nice work!"
    : `${5 - missionPatches} mission ${5 - missionPatches === 1 ? "patch" : "patches"} left to find.`;
  showGameToast(message);
}

function unlockMissionPatch(siteId) {
  const mission = missions[siteId];
  if (!mission || !document.querySelector(`.passport-patch[data-passport-badge="${siteId}"]`)) return;
  unlockPassportBadge(siteId, `${mission.name} mission patch earned!`);
}

function renderSignalQuestion() {
  const question = signalQuestions[quizRound];
  quizAnswered = false;
  byId("quiz-round-label").textContent = `SIGNAL ${String(quizRound + 1).padStart(2, "0")} / 03`;
  byId("quiz-score-label").textContent = `SCORE ${String(quizScore).padStart(2, "0")}`;
  byId("quiz-question").textContent = question.question;
  byId("quiz-hint-text").textContent = question.hint;
  byId("quiz-choices").hidden = false;
  byId("quiz-feedback").hidden = true;
  byId("quiz-feedback").classList.remove("is-incorrect");
  document.querySelector(".quiz-hint").hidden = false;
  document.querySelectorAll(".quiz-choice").forEach((button, index) => {
    const [choiceId, label] = question.choices[index];
    const letter = document.createElement("span");
    letter.className = "choice-letter";
    letter.textContent = String.fromCharCode(65 + index);
    button.dataset.choice = choiceId;
    button.disabled = false;
    button.classList.remove("is-correct", "is-incorrect");
    button.replaceChildren(letter, document.createTextNode(label));
  });
  byId("quiz-progress-fill").style.width = `${(quizRound / signalQuestions.length) * 100}%`;
  document.querySelector(".quiz-progress").setAttribute("aria-valuenow", String(quizRound));
  byId("quiz-next").disabled = true;
  byId("quiz-next").innerHTML = 'Choose an answer <span aria-hidden="true">→</span>';
}

function answerSignalQuestion(button) {
  if (quizAnswered || quizComplete) return;
  quizAnswered = true;
  const question = signalQuestions[quizRound];
  const isCorrect = button.dataset.choice === question.answer;
  if (isCorrect) quizScore++;

  document.querySelectorAll(".quiz-choice").forEach(choice => {
    choice.disabled = true;
    if (choice.dataset.choice === question.answer) choice.classList.add("is-correct");
    else if (choice === button) choice.classList.add("is-incorrect");
  });
  byId("quiz-score-label").textContent = `SCORE ${String(quizScore).padStart(2, "0")}`;
  byId("quiz-feedback-mark").textContent = isCorrect ? "✦" : "↗";
  byId("quiz-feedback-text").textContent = `${isCorrect ? "Correct signal!" : "Not quite—here’s the clue."} ${question.explanation}`;
  byId("quiz-feedback").classList.toggle("is-incorrect", !isCorrect);
  byId("quiz-feedback").hidden = false;
  byId("quiz-progress-fill").style.width = `${((quizRound + 1) / signalQuestions.length) * 100}%`;
  document.querySelector(".quiz-progress").setAttribute("aria-valuenow", String(quizRound + 1));
  byId("quiz-next").disabled = false;
  byId("quiz-next").innerHTML = quizRound === signalQuestions.length - 1
    ? 'Finish signal hunt <span aria-hidden="true">↗</span>'
    : 'Next clue <span aria-hidden="true">→</span>';
}

function finishSignalHunt() {
  quizComplete = true;
  byId("quiz-round-label").textContent = "HUNT COMPLETE";
  byId("quiz-question").textContent = quizScore === signalQuestions.length
    ? "Perfect signal. You found every mission."
    : `You identified ${quizScore} of ${signalQuestions.length} missions.`;
  document.querySelector(".quiz-hint").hidden = true;
  byId("quiz-choices").hidden = true;
  byId("quiz-feedback").classList.remove("is-incorrect");
  byId("quiz-feedback-mark").textContent = "✦";
  byId("quiz-feedback-text").textContent = "Your Signal Sleuth patch is unlocked. Explore the map to collect the five mission patches too.";
  byId("quiz-feedback").hidden = false;
  byId("quiz-next").textContent = "Play again";
  unlockPassportBadge("signal-hunt", "Signal Sleuth patch earned!");
}

function resetSignalHunt() {
  quizRound = 0;
  quizScore = 0;
  quizComplete = false;
  renderSignalQuestion();
}

document.querySelectorAll(".quiz-choice").forEach(button => {
  button.addEventListener("click", () => answerSignalQuestion(button));
});
byId("quiz-next").addEventListener("click", () => {
  if (quizComplete) {
    resetSignalHunt();
  } else if (quizAnswered && quizRound < signalQuestions.length - 1) {
    quizRound++;
    renderSignalQuestion();
  } else if (quizAnswered) {
    finishSignalHunt();
  }
});

renderSignalQuestion();
setWorld("mars");
selectSite("curiosity");
document.querySelector('.hotspot[data-hotspot="power"]').classList.add("is-active");
